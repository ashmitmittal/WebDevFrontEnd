let customSelect, selElmnt, temp, temp2;
customSelect = document.getElementsByClassName('custom-select-1');
for (let i = 0; i < customSelect.length; i++) {
	selElmnt = customSelect[i].getElementsByClassName('selecttag')[0];
	/*for each element, create a new DIV that will act as the selected item:*/
	temp = document.createElement('DIV');
	temp.setAttribute('class', 'select-selected');
	temp.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
	customSelect[i].appendChild(temp);
	/*for each element, create a new DIV that will contain the option list:*/
	temp2 = document.createElement('DIV');
	temp2.setAttribute('class', 'select-items select-hide');
	for (let j = 1; j < selElmnt.length; j++) {
		let c;
		/*for each option in the original select element,
    create a new DIV that will act as an option item:*/
		c = document.createElement('DIV');
		c.innerHTML = selElmnt.options[j].innerHTML;
		c.addEventListener('click', function (e) {
			/*when an item is clicked, update the original select box,
        and the selected item:*/
			let y, i, k, s, h;
			s = this.parentNode.parentNode.getElementsByTagName('select')[0];
			h = this.parentNode.previousSibling;
			for (i = 0; i < s.length; i++) {
				if (s.options[i].innerHTML == this.innerHTML) {
					s.selectedIndex = i;
					h.innerHTML = this.innerHTML;
					y = this.parentNode.getElementsByClassName('same-as-selected');
					for (k = 0; k < y.length; k++) {
						y[k].removeAttribute('class');
					}
					this.setAttribute('class', 'same-as-selected');
					break;
				}
			}
			h.click();
		});
		temp2.appendChild(c);
	}
	customSelect[i].appendChild(temp2);
	temp.addEventListener('click', function (e) {
		/*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
		e.stopPropagation();
		closeAllSelect(this);
		this.nextSibling.classList.toggle('select-hide');
		this.classList.toggle('select-arrow-active');
	});
}
function closeAllSelect(elmnt) {
	/*a function that will close all select boxes in the document,
  except the current select box:*/
	let x,
		y,
		arrNo = [];
	x = document.getElementsByClassName('select-items');
	y = document.getElementsByClassName('select-selected');
	for (let i = 0; i < y.length; i++) {
		if (elmnt == y[i]) {
			arrNo.push(i);
		} else {
			y[i].classList.remove('select-arrow-active');
		}
	}
	for (i = 0; i < x.length; i++) {
		if (arrNo.indexOf(i)) {
			x[i].classList.add('select-hide');
		}
	}
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener('click', closeAllSelect);

$('.select-items').click(() => {
	console.log($('.selecttag').val());
});
